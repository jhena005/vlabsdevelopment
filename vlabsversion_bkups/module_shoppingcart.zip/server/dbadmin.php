<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

/*
 * dbadmin.php
 *
 * This class contains methods concerned with the eFront
 * vLabs modules database administration.
 *
 */


require_once((dirname(__FILE__)).'/db/db.php');


//$config_file = "checkout/google_checkout/google.conf"; jh
//$comment = "#"; jh

/*
$fp = fopen($config_file, "r");

while (!feof($fp)) {
  $line = trim(fgets($fp));
  if ($line && !ereg("^$comment", $line)) {
    $pieces = explode("=", $line);
    $option = trim($pieces[0]);
    $value = trim($pieces[1]);
    $config_values[$option] = $value;
  }
}
fclose($fp);
*/ 


/*

$Grequest = new GoogleRequest($merchant_id, $merchant_key, $server_type, $currency);
*/

if (isset($_POST['action'])) {
	$action = $_POST['action'];
} else {
	$action = "";
}


if (isset($_POST['email'])) {
	$email = $_POST['email'];
} else {
	$email = "";
}


//Reload orders of an specific user depending on who is logged in
if ($action == "getModules") {

	//echo '<script type="text/javascript">alert("In reloadOrders")</script>';
	
		//echo '<script type="text/javascript">alert("user id is: '.$userid .'")</script>';
	//call to the db
	$modules = db_getModules();
	//echo '<script type="text/javascript">alert("after db_getUserById")</script>';

    echo json_encode($modules);

	//Reload all orders of all users. Only used for administartor view
}

if ($action =="exportData"){

$moduleId ="";
$outputfile = "NEW_module_vlabs_shoppingcart_data.sql";
if (isset($_POST['modId'])) {
    $moduleId = $_POST['modId'];
} else {
    $moduleId = "";
}


//echo "moduleId is: " .$moduleId . PHP_EOL;

    if($moduleId!=""){
        $modulePrefix = eF_getTableData('module_vlabs_shoppingcart_dbadmin', 'moduleprefix', 'id='. $moduleId);

        //echo '<script type="text/javascript">alert("Current theme  is: ' . $tid[0]['name'] . '")</script>';
/*jh this is a good Idea but since the order in which tables are exported
and exported matters due to referential contraints, this can be done
as a second phase since time is of the escence now!

        $tableList ="";

        $sql = 'select TABLE_NAME from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "' . $modulePrefix[0]['moduleprefix'] .'%"';
        $result = eF_executeQuery($sql);
        $tables_array = array();
        if($result!=null){
            foreach($result as $r){
                $t_array = array(
                    "tableName"=>$r['TABLE_NAME']
                );
                array_push($tables_array,$t_array);
                $tableList .= $r['TABLE_NAME'] . " ";
            }


        }
        //echo "list of tables: " .PHP_EOL;
        //echo $tableList;
        //var_dump($tables_array);
        $output = shell_exec('mysqldump -u '.G_DBUSER.' -p'.G_DBPASSWD.' --no-create-info efront ' . $tableList .' >'. G_ROOTPATH .'www/modules/NEW_module_vlabs_shoppingcart_data.sql');
*/
        $output = shell_exec('mysqldump -u '.G_DBUSER.' -p'.G_DBPASSWD.' --no-create-info efront module_vlabs_shoppingcart module_vlabs_shoppingcart_store_inventory module_vlabs_shoppingcart_order module_vlabs_shoppingcart_payment_method module_vlabs_shoppingcart_user_payment module_vlabs_shoppingcart_order_summary module_vlabs_shoppingcart_package_summary module_vlabs_shoppingcart_preassignment module_vlabs_shoppingcart_log module_vlabs_shoppingcart_dbadmin >'. G_ROOTPATH .'www/modules/'.$outputfile);

        echo "pass";
    }else{
       echo "failed";
    }
}


?>
